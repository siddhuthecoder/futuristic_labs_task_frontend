import React from 'react';

const GridComponent = ({ component }) => {
  return <div style={{ ...component.style }}>Grid Layout</div>;
};

export default GridComponent;
