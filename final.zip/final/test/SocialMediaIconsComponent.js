import React from 'react';

const SocialMediaIconsComponent = ({ component }) => {
  return <div style={{ ...component.style }}>Social Media Icons</div>;
};

export default SocialMediaIconsComponent;
